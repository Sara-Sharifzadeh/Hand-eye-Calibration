function Pose=PoseFinder(fileName)
% filename = 'scn_pointByPoint0001.dat';
% delimiterIn = ' ';
% headerlinesIn = 1:6;
% range='A2:G12'
% A = importdata(filename,delimiterIn,headerlinesIn,'range',range);

fid = fopen(fileName);%'scn_pointByPoint0001.dat'

allLines = {};
allLines{1} = fgetl(fid);
while ischar(allLines{end})
    allLines{end+1} = fgetl(fid);
end

fclose(fid);

Pose=zeros(1,6);
for i=1:length(allLines)
    if ~isempty(allLines{i})
   if strcmp(allLines{i}(1),'r')==1%rotation
      tpm= textscan(allLines{i},'%s  %f %f %f');
      Pose(1,1)=tpm{2}; Pose(1,2)=tpm{3};Pose(1,3)=tpm{4};
   end
   if strcmp(allLines{i}(1),'t')==1%translation
       tpm= textscan(allLines{i},'%s  %f %f %f');
      Pose(1,4)=tpm{2}; Pose(1,5)=tpm{3};Pose(1,6)=tpm{4};
   end
    end
end
       

