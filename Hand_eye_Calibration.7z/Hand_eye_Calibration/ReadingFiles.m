clc;
close all;
clear all
listing = dir('*.txt');num=length(listing);
%% reading files
Poses=zeros(num,6);
ScanLine=cell(1,num);

for i=1:num
      ScanLine{i}=importdata(strcat('xzData_',num2str(i),'.txt'));
    if i<10
       Poses(i,:)=PoseFinder(strcat('scn_pointByPoint000',num2str(i),'.dat'));
    elseif 10<=i&&i<100
        Poses(i,:)=PoseFinder(strcat('scn_pointByPoint00',num2str(i),'.dat'));
    elseif i>=100
        Poses(i,:)=PoseFinder(strcat('scn_pointByPoint0',num2str(i),'.dat'));
    end
end
save('ScanLine','ScanLine');save('Poses','Poses')

%%