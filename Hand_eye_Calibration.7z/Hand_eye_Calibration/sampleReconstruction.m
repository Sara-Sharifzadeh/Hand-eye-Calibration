% reconstruction code for circular pattern and comparision with the
% simulated patterns
%% Sara Sharifzadeh 2017
clc
clear all
load ScanLine;load Poses;
load HEtf_s_circ;load infocirc
% mx_depth=1;

% 3D reconst.
Psen=zeros(200,3);
rabt=[];
targ_mat_cck1=[];
co=1;
for i=2:2:length(Poses)
    [Hrb_tf1]=R_form_compense2(Poses(i,:)');
    [p,n]=size(ScanLine{i});
    mat=[ScanLine{i}(1,:);zeros(1,n);ScanLine{i}(2,:);ones(1,n)];%homo form x,y,z,1 mm
    id=find(mat(3,:)==0);
   % for reconst

    tp1=Hrb_tf1*HEtf_s_circ{2}*mat;
    tp1=tp1';tp1(tp1(:,3)>-100,:)=[];%remove unwanted lines
    tp1(:,3)=tp1(:,3)-19;%compensate for the added bias to the robot tool
    targ_mat_cck1=[targ_mat_cck1;tp1(:,1:3)];
    % for data prep
    tpc=ScanLine{i}';tpc(find(tpc(:,2)==0),:)=[];
    if ~isempty(tpc)
    Trbtf{co}=Hrb_tf1;
    stp= fix(length(tpc)/200);%takig 200 points per line
    tpp=tpc(1:stp:length(tpc),:);
    Psen((co-1)*200+1:co*200,[1,3])=tpp(1:200,:);
    co=co+1;
    end
end
figure,
scatter3(targ_mat_cck1(:,1),targ_mat_cck1(:,2),targ_mat_cck1(:,3),'.')
xlabel('x (mm)'),ylabel('y (mm)'),zlabel('z (mm)')
hold on, 
for i=1:length(infocirc.Orig_Line)
hold on,plot3(infocirc.Orig_Line{i}(:,1),infocirc.Orig_Line{i}(:,2),infocirc.Orig_Line{i}(:,3),'or','linewidth',3)
end
legend('reconstructed scanned lines','simulated lines')

