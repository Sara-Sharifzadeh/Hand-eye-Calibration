% conversion from 6 scan numbers into 3d homogenous transformation matrix
%% Sara Sharifzadeh 2017 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [H]=R_form_compense2(pose)

p=degtorad(pose(1:3));%to radian
a=p(1);b=p(2);c=p(3);

%anti-clockwise
Rx=[1 0 0 ;0 cos(a) -sin(a) ;0 sin(a) cos(a) ];
Ry=[cos(b) 0 sin(b) ;0 1 0 ;-sin(b) 0  cos(b) ];
Rz=[cos(c) -sin(c) 0 ;sin(c) cos(c) 0  ;0 0 1 ];

 R=Rz*Ry*Rx;% roll-pitch-yaw

%endefector to tool pose info
deltax=0;deltay=-50;deltaz=110;

% tetax=0;tetay=0;tetaz=0;
trans=[1000*(pose(4));1000*(pose(5));1000*(pose(6))]-R*[deltax ;deltay ;deltaz ];
H=[[R;zeros(1,3)] [trans;1] ];
